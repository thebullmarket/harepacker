MapleLib2 by haha01haha01;
based on MapleLib by Snow;
based on WzLib by JonyLeeson;
based on information from Fiel\Koolk.