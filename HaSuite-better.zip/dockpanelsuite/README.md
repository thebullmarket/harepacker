dockpanelsuite
==============

DockPanel Suite - The Visual Studio inspired docking library for .NET WinForms

For all the details, check out [http://dockpanelsuite.com](http://dockpanelsuite.com).
