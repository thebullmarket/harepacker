APNG library

Made from a version of libpng patched with the patches from (http://sourceforge.net/projects/apng/), zlib, and some code from tga2apng.

The LICENSE in this folder (GPLv3) does not apply to files in the subfolders; they have their own LICENSE files (libpng license for the patched libpng, and zlib license for zlib).